-- Traffic Bottleneck Database Backup
-- Created: 2026-01-25T11:00:24.014646
-- Tables: algorithms, backups, users

-- Table: algorithms (5 rows)
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (1, 'LIM', 'Monte Carlo simulation with probabilistic spread for traffic jam prediction', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Linear Independent Cascade', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (2, 'LTM', 'Threshold-based activation model for congestion spread', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Linear Threshold Model', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (3, 'SIR', 'Epidemic model for traffic congestion with recovery', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Susceptible-Infected-Recovered', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (4, 'SIS', 'Epidemic model allowing re-infection for persistent congestion', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Susceptible-Infected-Susceptible', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (5, 'GREEDY', 'Iterative selection algorithm for top-K bottleneck identification', FALSE, '2026-01-24T07:29:59.347346', '2026-01-21T11:56:40.536829', 'Greedy Bottleneck Finder', 'optimization', 'temp', '{}', '2026-01-24T07:29:59.347346');

-- Table: backups (1 rows)
INSERT INTO backups (id, filename, file_size, created_by, created_at, notes, file_path, backup_type, status, tables_included, is_deleted, deleted_at) VALUES (4, 'backup_partial_20260125_104309.sql.gz', 5450, 22, '2026-01-25T05:13:10.986061', '', 'C:\Users\Hi\Downloads\Traffic Bottleneck new\TrafficAnalysis\backend\backups\backup_partial_20260125_104309.sql.gz', 'partial', 'completed', '["algorithms", "backups", "bookmarks", "bottleneck_rankings", "users", "users_backup"]', FALSE, NULL);

-- Table: users - SKIPPED (contains duplicate columns: updated_at, is_super_admin, id, created_at, role, email)
-- Note: This table has a schema issue that needs to be fixed before backup

