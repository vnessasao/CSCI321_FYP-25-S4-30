-- Traffic Bottleneck Database Backup
-- Created: 2026-01-25T11:38:44.006611
-- Tables: algorithms, backups, bookmarks, bottleneck_rankings, congestion_states, detected_anomalies, feedback, gps_trajectories, incidents, influence_probabilities, model_schedules, permissions, road_edges, road_nodes, role_permissions, route_bookmarks, system_logs, upload_sessions, users, users_backup

-- Table: algorithms (5 rows)
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (1, 'LIM', 'Monte Carlo simulation with probabilistic spread for traffic jam prediction', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Linear Independent Cascade', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (2, 'LTM', 'Threshold-based activation model for congestion spread', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Linear Threshold Model', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (3, 'SIR', 'Epidemic model for traffic congestion with recovery', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Susceptible-Infected-Recovered', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (4, 'SIS', 'Epidemic model allowing re-infection for persistent congestion', TRUE, NULL, '2026-01-21T11:56:40.536829', 'Susceptible-Infected-Susceptible', 'spread_model', NULL, '{}', '2026-01-21T11:56:40.536829');
INSERT INTO algorithms (id, name, description, is_active, suspended_at, created_at, display_name, model_type, suspended_reason, parameters, updated_at) VALUES (5, 'GREEDY', 'Iterative selection algorithm for top-K bottleneck identification', FALSE, '2026-01-24T07:29:59.347346', '2026-01-21T11:56:40.536829', 'Greedy Bottleneck Finder', 'optimization', 'temp', '{}', '2026-01-24T07:29:59.347346');

-- Table: backups (0 rows)

-- Table: bookmarks (2 rows)
INSERT INTO bookmarks (id, user_id, name, latitude, longitude, address, notes, created_at, updated_at) VALUES (2, 3, 'Office', '1.36578021', '103.77619281', NULL, 'My office', '2026-01-10T13:39:04.228019', '2026-01-10T13:39:04.228019');
INSERT INTO bookmarks (id, user_id, name, latitude, longitude, address, notes, created_at, updated_at) VALUES (3, 20, 'Marina East', '1.28931723', '103.87470245', NULL, NULL, '2026-01-22T09:15:14.616114', '2026-01-22T09:15:14.616114');

-- Table: bottleneck_rankings (0 rows)

-- Table: congestion_states (0 rows)

-- Table: detected_anomalies (0 rows)

-- Table: feedback (6 rows)
INSERT INTO feedback (id, user_id, user_email, category, message, is_broadcast, broadcast_message, broadcast_at, created_at, user_name, subject, rating, status, broadcast_by, admin_response, responded_by, responded_at) VALUES (2, 22, 'develop123@gmail.com', 'data_quality', 'testing', FALSE, NULL, NULL, '2026-01-23T05:08:06.991603', NULL, 'asa', 3, 'resolved', NULL, 'test response', 22, '2026-01-23T05:09:01.257766');
INSERT INTO feedback (id, user_id, user_email, category, message, is_broadcast, broadcast_message, broadcast_at, created_at, user_name, subject, rating, status, broadcast_by, admin_response, responded_by, responded_at) VALUES (3, 16, 'abcd@gmail.com', 'feature_request', 'test', FALSE, NULL, NULL, '2026-01-23T05:16:07.612960', NULL, '', 3, 'resolved', NULL, 'resolved', 22, '2026-01-23T05:16:45.000345');
INSERT INTO feedback (id, user_id, user_email, category, message, is_broadcast, broadcast_message, broadcast_at, created_at, user_name, subject, rating, status, broadcast_by, admin_response, responded_by, responded_at) VALUES (4, 22, 'develop123@gmail.com', 'bug_report', 'new', FALSE, NULL, NULL, '2026-01-23T05:17:30.489570', NULL, '', NULL, 'resolved', NULL, 'bug resolved', 22, '2026-01-23T05:17:52.682875');
INSERT INTO feedback (id, user_id, user_email, category, message, is_broadcast, broadcast_message, broadcast_at, created_at, user_name, subject, rating, status, broadcast_by, admin_response, responded_by, responded_at) VALUES (5, 16, 'abcd@gmail.com', 'usability', 'problem solved - 24.01.2026', TRUE, 'problem solved - 24.01.2026', '2026-01-24T04:39:50.441800', '2026-01-24T04:28:12.588814', NULL, '', 5, 'broadcast', 22, NULL, NULL, NULL);
INSERT INTO feedback (id, user_id, user_email, category, message, is_broadcast, broadcast_message, broadcast_at, created_at, user_name, subject, rating, status, broadcast_by, admin_response, responded_by, responded_at) VALUES (6, 16, 'abcd@gmail.com', 'data_quality', 'test - notification - done', TRUE, 'test - notification - done', '2026-01-24T04:50:08.132297', '2026-01-24T04:49:23.466897', NULL, '', NULL, 'broadcast', 22, NULL, NULL, NULL);
INSERT INTO feedback (id, user_id, user_email, category, message, is_broadcast, broadcast_message, broadcast_at, created_at, user_name, subject, rating, status, broadcast_by, admin_response, responded_by, responded_at) VALUES (7, 16, 'abcd@gmail.com', 'general', 'notification - test 2 done', FALSE, NULL, NULL, '2026-01-24T04:53:24.680578', NULL, '', NULL, 'pending', NULL, NULL, NULL, NULL);

-- Table: gps_trajectories (0 rows)

-- Table: incidents (0 rows)

-- Table: influence_probabilities (0 rows)

-- Table: model_schedules (0 rows)

-- Table: permissions (0 rows)

-- Table: road_edges (0 rows)

-- Table: road_nodes (0 rows)

-- Table: role_permissions (0 rows)

-- Table: route_bookmarks (0 rows)

-- Table: system_logs (0 rows)

-- Table: upload_sessions (0 rows)

-- Table: users (0 rows)

-- Table: users_backup (0 rows)

